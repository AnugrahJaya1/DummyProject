<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Code For Social</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            /* height: 100vh; */
            margin: 0;
        }

        .flex-center {
            align-items: center;
            /* display: flex; */
            justify-content: center;
        }

        li {
            margin-bottom: 10px;
            margin-top: 10px;
        }

        .position-ref {
            position: relative;
            margin-bottom: 65px;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
            /* position: absolute; */
        }

        .title {
            font-size: 84px;
        }


        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }

        a {
            color: black;
            text-decoration: none;
        }

        a:hover {
            color: black;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="flex-center position-ref">
        <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">Login</a>

            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>">Register</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <div class="content">
            <div class="title m-b-md">
                Code For Social
            </div>

            <div>
                <h2>FORMULIR GAMBARAN ANAK DARI SUDUT PANDANG ORANG TUA</h2>
            </div>

        </div>
    </div>
    <div class="container">
        <form action="/test" method="post">
            <?php echo csrf_field(); ?>
            <table>
                <tr>
                    <td>
                        <h3>Nama : </h3>
                    </td>
                    <td>
                        <input type="text" name="name" size="50" value=<?php echo e($data['name']); ?>>
                    </td>
                </tr>
            </table>

    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\PDF1\resources\views//test.blade.php ENDPATH**/ ?>