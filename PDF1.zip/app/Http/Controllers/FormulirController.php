<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PDF;

class FormulirController extends Controller
{
    function index(Request $req)
    {
        // ini_set('max_execution_time', 300);
        // ini_set("memory_limit", "512M");
        $data = $req->input();
        print_r($data);
        view()->share('data', $data);
        $pdf = PDF::loadView('pdf');
        $pdf->setTemporaryFolder(storage_path('tmp'));
        return $pdf->download('result.pdf');



        return view('/pdf');
    }
}
